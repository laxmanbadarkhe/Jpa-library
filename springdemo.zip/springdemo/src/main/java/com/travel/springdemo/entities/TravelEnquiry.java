package com.travel.springdemo.entities;

public class TravelEnquiry {
    public int enqid;
	public String Custnm;
	public String Mob;
	public String Traveltype;
	public String Destination;
	public String Travelyears;
	public String Day;
	public String Adult;
	public String Child;
	
	
	public int getEnqid() {
		return enqid;
	}
	public void setEnqid(int enqid) {
		this.enqid = enqid;
	}
	public String getCustnm() {
		return Custnm;
	}
	public void setCustnm(String custnm) {
		Custnm = custnm;
	}
	public String getMob() {
		return Mob;
	}
	public void setMob(String mob) {
		Mob = mob;
	}
	public String getTraveltype() {
		return Traveltype;
	}
	public void setTraveltype(String traveltype) {
		Traveltype = traveltype;
	}
	public String getDestination() {
		return Destination;
	}
	public void setDestination(String destination) {
		Destination = destination;
	}
	public String getTravelyears() {
		return Travelyears;
	}
	public void setTravelyears(String travelyears) {
		Travelyears = travelyears;
	}
	public String getDay() {
		return Day;
	}
	public void setDay(String day) {
		Day = day;
	}
	public String getAdult() {
		return Adult;
	}
	public void setAdult(String adult) {
		Adult = adult;
	}
	public String getChild() {
		return Child;
	}
	public void setChild(String child) {
		Child = child;
	}
	
	
}
