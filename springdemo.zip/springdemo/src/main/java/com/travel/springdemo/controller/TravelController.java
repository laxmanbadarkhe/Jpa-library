package com.travel.springdemo.controller;


import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.travel.springdemo.entities.Customer;
import com.travel.springdemo.entities.TravelEnquiry;
import com.travel.springdemo.services.CustomerServies;
import com.travel.springdemo.services.TravelService;

import jakarta.servlet.http.HttpSession;



@Controller
public class TravelController {
	
	@Autowired
   public  TravelService tserv;
	@Autowired
	public CustomerServies cserv;
	@GetMapping("/")
	public String home()
	{
		return"index.jsp";
	}
	@PostMapping("/login")
	public String login( String uid,String psw,HttpSession ses)
	{
		String stat=tserv.authenticate(uid,psw);
				
		if(stat.equals("success"))
		{
			ses.setAttribute("userid",uid);
			return "Traveladmin.jsp";
		}
		else
			return "Failed.jsp";
	}
	
	@GetMapping("/newenq")
	public String newEnq()
	{
		return "AddnewEnquiry.jsp";
		//return"index.jsp";
		
	}
	
	@PostMapping("/addnew")
	public String addnewenq(TravelEnquiry obj)
	{     
		String stat=tserv.addNewTravelEnquiry(obj);
		 return stat;
	}
	
	@PostMapping("/searchid")
	public ModelAndView showResult(int enqid)
	{
		ModelAndView mv=new ModelAndView();
		TravelEnquiry te=tserv.getSearchIDResult(enqid);
		mv.addObject("res",te);
		mv.setViewName("SearchIDResult.jsp");
		return mv;
		
	}
	@PostMapping("/searchonname")
	public ModelAndView searchname(String custnm)
	{
		ModelAndView mv=new ModelAndView();
		TravelEnquiry te=tserv.getsearchonname(custnm);
		mv.addObject("res",te);
		mv.setViewName("SeachOnNameResult.jsp");
		return mv;
	}
	@GetMapping("/updatenew")
	public String updatenew()
	{
		return"updatecustinfo.jsp";
	}
	@PostMapping("/update")
	public ModelAndView updateDest(int enqid,String traveltype,String destination)
	{
		int stat=tserv.update(enqid,traveltype,destination);
		String status="";
		ModelAndView mv=new ModelAndView();
		if (stat==1)
			status="success";
		else
			status="failed";
		mv.addObject("status",status);
		mv.setViewName("Updatesuccess.jsp");
		return mv;
	}
	
	@GetMapping("/custReport")
	public ModelAndView showAccReport()
	{
		ModelAndView mv=new ModelAndView();
		ArrayList<Customer> clist=cserv.getCustReport();
		mv.addObject("culist",clist);
		mv.setViewName("ShowCustReport.jsp");
		return mv;
		
	}
	@GetMapping("/deletecust")
	public String delnew()
	{
		return"deletecustoinfo.jsp";
	}
	@PostMapping("/delete")
	public ModelAndView delCust(int enqid)
	{   int stat=tserv.delete( enqid);
	    String status="";
		ModelAndView mv=new ModelAndView();
		if (stat==1)
			status="success";
		else
			status="failed";
		mv.addObject("status",status);
		mv.setViewName("Deletecustomer.jsp");
		return mv;
	}

}
