package com.travel.springdemo.services;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import org.springframework.stereotype.Service;

import com.travel.springdemo.entities.Customer;

@Service
public class CustomerServies {

public ArrayList<Customer> getCustReport()
{
	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	ArrayList<Customer> culist=new ArrayList<>();
	try
	{
		Class.forName("com.mysql.cj.jdbc.Driver");
	    con=DriverManager.getConnection("jdbc:mysql://uuqoxs7nlaj12x3c:cb96ZM8nYJcFmyM1wTZm@bqjidnwmafqmbvdckrim-mysql.services.clever-cloud.com:3306/bqjidnwmafqmbvdckrim");	
		pst=con.prepareStatement("select * from customer ");
		rs=pst.executeQuery();
		
		Customer cu;
		while(rs.next())
		{
		  cu=new Customer();
		  cu.setCustnm(rs.getString("custnm"));
		  cu.setCity(rs.getString("city"));
		  cu.setMobile(rs.getString("mobile"));
		  culist.add(cu);
		}
		con.close();
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
	return culist;
}

}
