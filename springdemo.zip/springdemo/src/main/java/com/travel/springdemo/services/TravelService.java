package com.travel.springdemo.services;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.springframework.stereotype.Service;

import com.travel.springdemo.entities.TravelEnquiry;

@Service
public class TravelService {

public String authenticate(String uid,String psw)
{
	String status="";
if(uid.equals("spider") && psw.equals("laxman"))
	status="success";
else
	status="failed";
 
  return status;

}

public String addNewTravelEnquiry(TravelEnquiry obj)
{
	String status="";
   Connection con;
   PreparedStatement pst;
   
   try
   {
	   
	   Class.forName("com.mysql.cj.jdbc.Driver");
	   con=DriverManager.getConnection("jdbc:mysql://uuqoxs7nlaj12x3c:cb96ZM8nYJcFmyM1wTZm@bqjidnwmafqmbvdckrim-mysql.services.clever-cloud.com:3306/bqjidnwmafqmbvdckrim");
	   pst=con.prepareStatement("insert into TravelEnquiry(custnm,mob,traveltype,destination,travelyears,day,adult,child)value(?,?,?,?,?,?,?,?)");
	   pst.setString(1,obj.getCustnm());
	   pst.setString(2,obj.getMob());
	   pst.setString(3,obj.getTraveltype());
	   pst.setString(4,obj.getDestination());
	   pst.setString(5,obj.getTravelyears());
	   pst.setString(6,obj.getDay());
	   pst.setString(7,obj.getAdult());
	   pst.setString(8,obj.getChild());
	   pst.executeUpdate();
	   con.close();
	    status="EnqDone.jsp";
   }
   catch(Exception e)
   {    
	  System.out.println(e); 
	   status="EnqFailed.jsp";
   }
   return status;
}

public TravelEnquiry getSearchIDResult(int enqid)
{
	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	TravelEnquiry obj=new TravelEnquiry();
	try
	{
	   Class.forName("com.mysql.cj.jdbc.Driver");
	    con=DriverManager.getConnection("jdbc:mysql://uuqoxs7nlaj12x3c:cb96ZM8nYJcFmyM1wTZm@bqjidnwmafqmbvdckrim-mysql.services.clever-cloud.com:3306/bqjidnwmafqmbvdckrim");	
		pst=con.prepareStatement("select * from TravelEnquiry where enqid=? ");
		pst.setInt(1,enqid);
		rs=pst.executeQuery();
		if(rs.next())
		{
			obj.setCustnm(rs.getString("custnm"));
			obj.setMob(rs.getString("mob"));
			obj.setDestination(rs.getString("Destination"));
		}
		
		else
		{
		obj.setCustnm("not found");	
	    }
		con.close();
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
	return obj;
	
}

public  TravelEnquiry getsearchonname(String custnm)
{

	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	TravelEnquiry obj=new TravelEnquiry();
	try
	{
	   Class.forName("com.mysql.cj.jdbc.Driver");
	    con=DriverManager.getConnection("jdbc:mysql://uuqoxs7nlaj12x3c:cb96ZM8nYJcFmyM1wTZm@bqjidnwmafqmbvdckrim-mysql.services.clever-cloud.com:3306/bqjidnwmafqmbvdckrim");	
		pst=con.prepareStatement("select * from TravelEnquiry where custnm=? ");
		pst.setString(1,custnm);
		rs=pst.executeQuery();
		if(rs.next())
		{
			obj.setCustnm(rs.getString("custnm"));
			obj.setMob(rs.getString("mob"));
			obj.setDestination(rs.getString("Destination"));
		}
		
		else
		{
		obj.setCustnm("not found");	
	    }
		con.close();
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
	return obj;
	
}

public int update(int eno,String type, String dest)
{
	Connection con;
	PreparedStatement pst;
  int stat=0;
try
{
	Class.forName("com.mysql.cj.jdbc.Driver");
    con=DriverManager.getConnection("jdbc:mysql://uuqoxs7nlaj12x3c:cb96ZM8nYJcFmyM1wTZm@bqjidnwmafqmbvdckrim-mysql.services.clever-cloud.com:3306/bqjidnwmafqmbvdckrim");	
	pst=con.prepareStatement("update TravelEnquiry set traveltype=?,destination=? where enqid=?");
	pst.setString(1,type);
	pst.setString(2,dest);
	pst.setInt(3,eno);
	stat=pst.executeUpdate();
	con.close();
}
catch(Exception e)
{
System.out.println(e);	
}
return stat;
}

   public int delete(int eno)
{ Connection con;
  PreparedStatement pst;
  int stat=0;
try
{
Class.forName("com.mysql.cj.jdbc.Driver");
con=DriverManager.getConnection("jdbc:mysql://uuqoxs7nlaj12x3c:cb96ZM8nYJcFmyM1wTZm@bqjidnwmafqmbvdckrim-mysql.services.clever-cloud.com:3306/bqjidnwmafqmbvdckrim");	
pst=con.prepareStatement("delete from TravelEnquiry where enqid=?");
pst.setInt(1,eno);
stat=pst.executeUpdate();
con.close();
}
catch(Exception e)
{
System.out.println(e);	
}
return stat;
}
}
