package com.laxman.jpalibrary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpalibraryApplicationTests {

	@Test
	void contextLoads() {
	}

}
