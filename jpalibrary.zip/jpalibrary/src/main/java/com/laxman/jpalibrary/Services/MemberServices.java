package com.laxman.jpalibrary.Services;
import org.springframework.beans.factory.annotation.Autowired;



import org.springframework.stereotype.Service;
import com.laxman.jpalibrary.Entities.Member;
import com.laxman.jpalibrary.Repositories.MemberRepository;




@Service
public class MemberServices {
	@Autowired
	private MemberRepository memRepo;
	
	public String addNewMember(Member obj)
	{
		memRepo.save(obj);
		return"success";
	}
	
	
	public String addUpdate(Member obj)
	{
		memRepo.save(obj);
		return"success";
	}
	
	
	
	
}