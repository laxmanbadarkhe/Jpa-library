package com.laxman.jpalibrary.Repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.laxman.jpalibrary.Entities.Book;

@Repository
public interface BookRpository extends JpaRepository<Book, Integer> {
Book findByBookid(int bookid);
Book findByGenre(String genre);
Book findByTitle(String title);
Book findByAuthor(String author);
List<Book> findByPrice(float price);
Book findByGenreAndLanguage(String genre,String language);
List<Book>findByPagesLessThan( int pages);
List<Book> findBypublicationyear(String publicationyear);
}
