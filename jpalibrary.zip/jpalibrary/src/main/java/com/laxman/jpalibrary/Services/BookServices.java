package com.laxman.jpalibrary.Services;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;
import com.laxman.jpalibrary.Entities.Book;
import com.laxman.jpalibrary.Repositories.BookRpository;

@Service
public class BookServices {
@Autowired
private BookRpository bookRepo;

public String addNewBook(Book obj)	
{
	bookRepo.save(obj);
	return"sucess";
}



}
