package com.laxman.jpalibrary;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;


import com.laxman.jpalibrary.Entities.Member;
import com.laxman.jpalibrary.Repositories.MemberRepository;
import com.laxman.jpalibrary.Services.MemberServices;

import jakarta.servlet.http.HttpSession;






@Controller
public class MemberController {
@Autowired
	private MemberServices memberServices;
@Autowired
private MemberRepository memRepo;
	@GetMapping("/addMb")
	public String addMember()
	{
		return"AddNewMember.html";
	}
	
	@PostMapping("/addmem")
	public String addnew(Member m,HttpSession ses)
	{
		String status=memberServices.addNewMember(m);
		ses.setAttribute("status",status);
		return"Status.jsp";
	}
	
	
	
	
	@GetMapping("/modimob")
	public String modifymobile()
	{
	return"ModifyMobile.jsp";	
	}
	
	@PostMapping("/updateMob")
	public String update(int memberid,String name,String mobile)
	{
		Member obj=memRepo.findByMemberid(memberid);
		obj.setMobile(mobile);
		memRepo.save(obj);
		return"Mobilestatus.jsp";
	}
	
	@PostMapping("/name")
	public ModelAndView searchOnName(String name )
	{
	ModelAndView mv=new ModelAndView();
	mv.setViewName("SearchResultOnName.jsp");
	Member obj=memRepo.findByName(name);
	if(obj!=null)
		System.out.println(obj.getMemberid());
	else
	{
	obj=new Member();
	obj.setMemberid(0);
	obj.setName("not found");
	obj.setGender("not found");
	
	}
	mv.addObject("member",obj);
	return mv;
	}

	@PostMapping("/join")
	public ModelAndView searchOnJoinyear(String joinyear )
	{
	ModelAndView mv=new ModelAndView();
	mv.setViewName("SearchResultOnJoinYear.jsp");
	
	List<Member> memberlist=memRepo.findByJoinyear(joinyear);
	mv.addObject("memberlist",memberlist);
	return mv;
	}

	
}
