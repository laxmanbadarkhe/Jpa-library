package com.laxman.jpalibrary;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpalibraryApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpalibraryApplication.class, args);
		System.out.println("laxman badarkhe");
	}

}
