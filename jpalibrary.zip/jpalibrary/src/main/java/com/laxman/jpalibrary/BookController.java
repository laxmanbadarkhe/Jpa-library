package com.laxman.jpalibrary;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.laxman.jpalibrary.Entities.Book;
import com.laxman.jpalibrary.Repositories.BookRpository;
import com.laxman.jpalibrary.Services.BookServices;

import jakarta.servlet.http.HttpSession;



@Controller
public class BookController {
@Autowired 
private BookServices bookServices;

@Autowired
private BookRpository bookRepo;

@GetMapping("/")
public String home()
{
	return"index1.jsp";
}
@GetMapping("/addbk")
public String addBook()
{
return"Addbook.html";	
}
@PostMapping("/addbook")
public String addBook(Book b,HttpSession ses)
{
	
	String status=bookServices.addNewBook(b);
	ses.setAttribute("status",status);
	return "ActivityStatus.jsp";
}

@GetMapping("/modiprc")
public String modifyprice()
{
	return"modifyprice.jsp";
}

@PostMapping("/update")
public  String updatePrice( int bookid,String title,float price)
{
	Book obj=bookRepo.findByBookid(bookid);
	obj.setPrice(price);
	bookRepo.save(obj);
	return"Pricestaus.jsp";
}	

@GetMapping("delbook")
public String deletebook()
{
return"Deletebook.jsp";	
}

@PostMapping("/delete")
public String removebook(int bookid)
{
	Book obj=bookRepo.findByBookid(bookid);
	bookRepo.delete(obj);
	return"Dbook.jsp";
}
@PostMapping("/author")
public ModelAndView searchOnAuthor(String author)
{
ModelAndView mv=new ModelAndView();
mv.setViewName("SearchResultOnAuthor.jsp");
Book obj=bookRepo.findByAuthor(author);
if(obj!=null)
	System.out.println(obj.getTitle());
else
{
obj=new Book();
obj.setBookid(0);
obj.setTitle("not found");
obj.setAuthor("not found");
obj.setPrice(0);
}
mv.addObject("book",obj);
return mv;
}

@PostMapping("/genre")
public ModelAndView searchOnGenre(String genre)
{
ModelAndView mv=new ModelAndView();
mv.setViewName("SearchResultOnGenre.jsp");
Book obj=bookRepo.findByGenre(genre);
if(obj!=null)
	System.out.println(obj.getBookid());
else
{
obj=new Book();
obj.setBookid(0);
obj.setTitle("not found");
obj.setAuthor("not found");
obj.setPrice(0);
}
mv.addObject("book",obj);
return mv;
}

@PostMapping("/price")
public ModelAndView searchOnPrice(float price)
{
ModelAndView mv=new ModelAndView();
mv.setViewName("SearchResultOnPrice.jsp");
List<Book> booklist=bookRepo.findByPrice(price);
System.out.println(booklist.size());
mv.addObject("booklist",booklist);
return mv;
}


@PostMapping("/language")
public ModelAndView searchOnLanguage(String genre,String language)
{
ModelAndView mv=new ModelAndView();
mv.setViewName("SearchResultOnGenreAndLanguage.jsp");
Book obj=bookRepo.findByGenreAndLanguage(genre,language);
if(obj!=null)
	System.out.println(obj.getBookid());
else
{
obj=new Book();
obj.setBookid(0);
obj.setTitle("not found");
obj.setGenre("not found");
obj.setLanguage("not found");
}
mv.addObject("book",obj);
return mv;
}

@PostMapping("/pages")
public ModelAndView searchOnPages(int pages )
{
ModelAndView mv=new ModelAndView();
mv.setViewName("SearchResultOnPages.jsp");
List<Book> booklist=bookRepo.findByPagesLessThan(pages);
System.out.println(booklist.size());
mv.addObject("booklist",booklist);
return mv;
}

@PostMapping("/year")
public ModelAndView searchOnYear(String publicationyear )
{
ModelAndView mv=new ModelAndView();
mv.setViewName("SearchResultOnYear.jsp");
List<Book> booklist=bookRepo.findBypublicationyear(publicationyear);
System.out.println(booklist.size());
mv.addObject("booklist",booklist);
return mv;
}

}

