package com.laxman.jpalibrary.Repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.laxman.jpalibrary.Entities.Member;

@Repository
public interface MemberRepository extends JpaRepository<Member, Integer>{
Member findByMemberid(int memberid);
Member findByName( String name);
List<Member> findByJoinyear(String joinyear);
}
